import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;


public class issueBOOK extends JFrame {

	private JPanel contentPane;
	JLabel bI,BT,P,Pr,Q,Author,C,SUB;
	JTextField t1,t2,t3,t4,t5,t6,t7;
	JButton b1,b2,b3,b4;
	  JMenuBar mb;  
      JMenu file,AddItem, help;  
      JMenuItem Home,Search,home, BNF;
	  String s1;

	/**
	 * Launch the application.
	 */
/*
	public static void main(String[] args) {
		
				try {
					issueBOOK frame = new issueBOOK("  issue Book","laxman" );
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
*/
	/**
	 * Create the frame.
	 */
	
	//Constructer 
	public issueBOOK( String title ,String username ) {
		super(title);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 505);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLayout(null);
		
	
		
		
		
	Home = new JMenuItem("Home");  
		
		Home.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0)
			
			{
				
					StudentSection frame= new  StudentSection("Student Section",username);
	    	 frame.setVisible(true);
	    	 dispose();
			}
			});
		
		Search = new JMenuItem("Search Book");  
		
		Search.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0)
			
			{
				SearchByStudent frame = new SearchByStudent("Search Book",username );
 				frame.setVisible(true);
 				dispose();	
			
			}
			});
		
	
  
	     mb=new JMenuBar();  
         mb.setBounds(0,0,1000,20);  
        file=new JMenu("File");  
       home=new JMenu("Home");  
         help=new JMenu("Help"); 
		 
		 BNF = new JMenuItem("WHAT IS BOOK ID");  
		   BNF.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent arg0)
				
				{
					
		
	 				int ans = JOptionPane.showConfirmDialog(getParent(),"PLEACE SEARCH BOOK ID FROM THE SEARCH PANEL AND PUT IN THIS FILL BOX \n why do you Want Search book Id ","SEARCH MESSAGE",JOptionPane.INFORMATION_MESSAGE);	
				
				
				if(ans==JOptionPane.YES_OPTION)
	{
		
	SearchByStudent frame = new SearchByStudent("Search Book",username );
 				frame.setVisible(true);
 			
		
	}
	else
	{
	Search frame = new Search("Search Book",username );
 				frame.setVisible(true);
 				dispose();	
		
	}
				
				
				}
				});
		 
		 //add new menu bar
         home.add(Home); home.add(Search) ;
   help.add(BNF); 
mb.add(file);mb.add(home);mb.add(help);
contentPane.add(mb);

			 
	   
	   
		//label of book
		bI= new JLabel("Book ID");
		SUB = new JLabel("SUBJECT");
		BT = new JLabel("Book Title");
		P = new JLabel("Publication");
		C = new JLabel("category");
		Author = new JLabel("Author");
		Pr = new JLabel("Prize");
		
		

		 
		 
		//book ID
	    t1 = new JTextField(10);
	 
	    
		
		   bI.setBounds(160,40,150,25);
		   t1.setBounds(350,40,250,25);
		
		contentPane.add(bI);
		contentPane.add( t1);
		
		
		

		
		
		  //book Title
		t2 = new JTextField(10);
		
	BT.setBounds(160,80,150,25);
	t2.setBounds(350,80,250,25);
			contentPane.add(BT);
		     contentPane.add(t2);
		     t2.setEditable(false);
		
		
		 //SUBJECT
		 	t3 = new JTextField(10);
		t3.setBounds(350,120,250,25);
			SUB.setBounds(160,120,150,25);
		contentPane.add(SUB);
		contentPane.add(t3);
		
		t3.setEditable(false);
		
		
		
		  //Author
		t4 = new JTextField(10);
	Author.setBounds(160,160,150,25);
		t4.setBounds(350,160,250,25);
		contentPane.add(Author);
	
		contentPane.add(t4);
		t4.setEditable(false);
		
		 
		
		
		  //Publication 
		
		t5 = new JTextField(10);
		P.setBounds(160,200,150,25);
		t5.setBounds(350,200,250,25);
	contentPane.add(P);
	
	contentPane.add(t5);
	t5.setEditable(false);
	
	
	   //category
	t6 = new JTextField(10);
	C.setBounds(160,240,150,25);
	t6.setBounds(350,240,250,25);
	contentPane.add(C);

	contentPane.add(t6);
	t6.setEditable(false);
	
	//Prize
	
	
	   t7 = new JTextField(10);
			t7.setBounds(350,280,250,25);
	Pr.setBounds(160,280,150,25);
		contentPane.add(Pr);
		contentPane.add(t7);
		t7.setEditable(false);
		
		
		
		
		
		b3 = new JButton("issue book");
		   b3.setBounds(100,360,250,25);
		        contentPane.add(b3);
		        b3.setVisible(false);
				 b3.addActionListener(new ActionListener(){
			
		
				int i = 0;
				int j = 0;
				int l = 0;
				public void actionPerformed(ActionEvent arg0)
				
				{
				
			
				
				
				
				String status = "Book is not in lib";
				
				//System.out.println("Author is ="+Aut);	
				String query1 = "update book set issueState = ? where BID= ?   ";
				  Connection con = DBINFO.getConnection();
				
				  
				  try{
					  
					  PreparedStatement ps = con.prepareStatement(query1); 
					 
					  ps.setString(1,status);
					   ps.setString(2,s1);
					  
					  
					  
					 l=  ps.executeUpdate();
					  
					  
				  }catch(Exception e){
						e.printStackTrace();
					}
					
					
				
				
				
				
				
				
				
				
				
				String query = " INSERT INTO `IssueB` (username,BID) VALUES(?,?) ";
					
					try
					{
						PreparedStatement ps = DBINFO.getConnection().prepareStatement(query);
						 ps.setString(1, username);
		                 ps.setString(2, s1);
		                  i =  ps.executeUpdate();
					
						
							
						
						
					}catch(Exception e){
						e.printStackTrace();
					}
					int j = DBINFO.DeletIssueBook( s1 );
					if(i==1&&j==1&&l==1)
					{
						
				JOptionPane.showMessageDialog(getParent(),"PLEACE SUBMIT BOOK AT GIVEN TIME "," MESSAGE",JOptionPane.INFORMATION_MESSAGE);	
				t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.setText(null);
					t6.setText(null);
					t7.setText(null);
					
			b3.setVisible(false);
			b4.setVisible(false);
			 dispose();
			 new issueBOOK("  issue Book",username ).setVisible(true);
					
			
					}
					else
					{
						
						 JOptionPane.showMessageDialog( getParent(),"book not  Found Pleace TRy AGAIN " ,"Error",JOptionPane.ERROR_MESSAGE);  
					}	
		
				}
				 
				 
				  
				});
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
		
						b4 = new JButton("Submit book");
		
		b4.setBounds(100,360,250,25);
		contentPane.add(b4);
		b4.setVisible(false);
		
		b4.addActionListener(new ActionListener(){
			int i =0;
			int l =0;
			int j =0;
			public void actionPerformed(ActionEvent arg0)
			{
				
				
				
				
				
				
				String status = "Book is in lib";
				
				//System.out.println("Author is ="+Aut);	
				String query1 = "update book set issueState = ? where BID= ?   ";
				  Connection con = DBINFO.getConnection();
				
				  
				  try{
					  
					  PreparedStatement ps = con.prepareStatement(query1); 
					 
					  ps.setString(1,status);
					   ps.setString(2,s1);
					  
					  
					  
					 j=  ps.executeUpdate();
					  
					  
				  }catch(Exception e){
						e.printStackTrace();
					}
				
				
				
				
				
					String query = " DELETE  FROM issueb where BID= ? and username = ? ";
					
					try
					{
						PreparedStatement ps = DBINFO.getConnection().prepareStatement(query);
						
						 ps.setString(1, s1);
		                 ps.setString(2,username);
		                  i =  ps.executeUpdate();
						
					}catch(Exception e){
						e.printStackTrace();
					}
					l  =DBINFO.SubmitBook(s1);
					if(i==1&&l==1&&j==1)
					{
						
				JOptionPane.showMessageDialog(getParent(),"YOU are SucceFull submit book "," MESSAGE",JOptionPane.INFORMATION_MESSAGE);	
				t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.setText(null);
					t6.setText(null);
					t7.setText(null);
						
			b3.setVisible(false);
			b4.setVisible(false);	
			 dispose();
			 new issueBOOK("  issue Book",username ).setVisible(true);
						
					}
				
				
			}
			
			
			
		});
	
		
		b1=new JButton("Search Book");
		
		 b1.addActionListener(new ActionListener(){
			
			 String s2,s3,s4,s5,s6,s7,s8,l1,l2,id1="";
				int Flag = 0;
				int Flag1 = 0;
				int Flag2 = 0;
				public void actionPerformed(ActionEvent arg0)
				
				{
					
							String id = t1.getText();
					String query1 = "select BID  from `nonissuebook` where BID=? ";;
					
					try
					{
						PreparedStatement ps = DBINFO.getConnection().prepareStatement(query1);
						ps.setString(1, id);
						ResultSet  res = ps.executeQuery();
						
								while(res.next())
								{
							      
								
									Flag1=1;
									break;
								
								}
						
						
					}catch(Exception e){
						e.printStackTrace();
					}
					
					
					
			
					
					
					
					
					
					
					
					
					
					
					
					
Flag2 =	DBINFO.SearchIssueBook1( s1,username );	
String query = " SELECT * FROM `book` where BID= ? ";
					
try
					{
						PreparedStatement ps = DBINFO.getConnection().prepareStatement(query);
						ps.setString(1, id);
						
						 ResultSet  res = ps.executeQuery();
						
								while(res.next())
								{
									s1 = res.getString(2);
									s2 = res.getString(3);
									s3 = res.getString(4);
									s4 = res.getString(5);
									s5 = res.getString(6);
									s6 = res.getString(7);
									s7 = res.getString(8);
									
									Flag=1;
									break;
								
								}
						
						
					}catch(Exception e){
						e.printStackTrace();
					}
					System.out.println("Flag = "+Flag);
						System.out.println("Flag1 = "+Flag1);
							System.out.println("Flag2 = "+Flag2);
					if(Flag==1&&Flag1==0&&Flag2==1)
					{
						
						t2.setText(s2);
						t3.setText(s3);
						t4.setText(s4);
						t5.setText(s5);
						t6.setText(s6);
						t7.setText(s7);
						
					b4.setVisible(true);
					b3.setVisible(false);
					System.out.println("BOOK id = "+s1);
					
					}
					 else if(Flag1==1&&Flag==1&&Flag2==0)
					
					{
						t2.setText(s2);
						t3.setText(s3);
						t4.setText(s4);
						t5.setText(s5);
						t6.setText(s6);
						t7.setText(s7);
						b4.setVisible(false);
					b3.setVisible(true);
					System.out.println("BOOK id = "+s1);	
						
						
					}					
					else if (Flag==1)
					{
					t2.setText(s2);
						t3.setText(s3);
						t4.setText(s4);
						t5.setText(s5);
						t6.setText(s6);
						t7.setText(s7);
						b4.setVisible(false);
					b3.setVisible(false);
					System.out.println("BOOK id = "+s1);	
						  
					}
else
{
	JOptionPane.showMessageDialog( getParent(),"book not  Found Pleace TRy AGAIN " ,"Error",JOptionPane.ERROR_MESSAGE); 
}	
		
				}
				 
				 
				  
				});

				
			
			b2=new JButton("Reset");
			b2.addActionListener(new ActionListener(){
				

				public void actionPerformed(ActionEvent arg0)
				
				{
					
			
					t1.setText(null);
					t2.setText(null);
					t3.setText(null);
					t4.setText(null);
					t5.setText(null);
					t6.setText(null);
					t7.setText(null);
					
			b3.setVisible(false);
			b4.setVisible(false);
			
				 dispose();
			 new issueBOOK("  issue Book",username ).setVisible(true);
					
				}});

			b1.setBounds(650,40,250,25);
			b2.setBounds(650,360,250,25);
				contentPane.add(b1);
				contentPane.add(b2);
				
				
				
	}
}
